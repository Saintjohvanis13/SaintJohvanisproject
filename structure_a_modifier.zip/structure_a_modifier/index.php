<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED); 
ini_set('display_errors', 1);
    //The front root controller

    //The requested route
    $route = null;
    if (isset($_GET['route'])) {
        $route = $_GET['route'];
    }
    
    //We switch to the good controller
    switch ($route) {
        case null:
            require('views/welcome_view.php');
            break;

        case 'families':
            require('controllers/family_ctrl.php');
            families_list_ctrl();
            break;
            
        case 'family':
            require('controllers/family_ctrl.php');
            family_print_ctrl();
            break;
            
        default:
            require('views/404_view.php');
            break;
            
    }

