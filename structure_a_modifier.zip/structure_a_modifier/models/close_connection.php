<?php
unset($connex);
?>